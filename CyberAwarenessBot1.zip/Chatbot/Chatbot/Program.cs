﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Speech.Synthesis;
using System.Linq;

public class Program
{
    private static SpeechSynthesizer? _speaker;

    public static void Main(string[] args)
    {
        InitializeSpeech();
        ShowLogo();
        Speak("Hi,Welcome to cybersercurity awareness bot, im here to help you stay safe online!");

        string userName = GetUserName();
        if (userName?.ToLower() == "exit") return;

        TypeEffect($"Cyborg: Hello {userName}! Welcome to the Cyber-Security Awareness Bot!\n");
        ShowTip();

        Dictionary<string, string> responses = GetResponses();
        ChatLoop(userName, responses);

        CleanupSpeech();
    }

    static void InitializeSpeech()
    {
        try
        {
            _speaker = new SpeechSynthesizer
            {
                Volume = 100,
                Rate = 0
            };
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine($"[Warning: Speech engine unavailable: {ex.Message}]");
            Console.ResetColor();
        }
    }

    static void CleanupSpeech()
    {
        _speaker?.Dispose();
        _speaker = null;
    }

    // ================= CORE METHODS =================

    static void ShowLogo()
    {
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine(@"
           ____      _                                                       
 / ___|   _| |__   ___ _ __                                         
| |  | | | | '_ \ / _ \ '__|                                        
| |__| |_| | |_) |  __/ |                                           
 \____\__, |_.__/ \___|_|                           _           _   
  __ _|___/   ____ _ _ __ ___ _ __   ___  ___ ___  | |__   ___ | |_ 
 / _` \ \ /\ / / _` | '__/ _ \ '_ \ / _ \/ __/ __| | '_ \ / _ \| __|
| (_| |\ V  V / (_| | | |  __/ | | |  __/\__ \__ \ | |_) | (_) | |_ 
 \__,_| \_/\_/ \__,_|_|  \___|_| |_|\___||___/___/ |_.__/ \___/ \__|                                
");
        Console.WriteLine(" [CYBERSECURITY AWARENESS BOT] ");
        Console.ResetColor();
    }

    static void Speak(string message)
    {
        if (_speaker == null) return;

        try
        {
            _speaker.SpeakAsyncCancelAll();
            _speaker.Speak(message);
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine($"[Speech error: {ex.Message}]");
            Console.ResetColor();
        }
    }

    static string GetUserName()
    {
        Console.ForegroundColor = ConsoleColor.DarkRed;
        Console.WriteLine("\nCyborg: What is your name?");
        Console.WriteLine("Cyborg: Type 'exit' anytime to quit");
        

        Console.ForegroundColor = ConsoleColor.DarkMagenta;
        Console.Write("You: ");
        return Console.ReadLine()?.Trim() ?? "";
    }
   
    static void ShowTip()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\nQuick Tip: Try asking about 'phishing', '2fa', 'ransomware', or 'password safety'!");
        Console.ResetColor();
    }

    static Dictionary<string, string> GetResponses()
    {
        return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            // === GREETINGS ===
            {"hi", "Hi! How can I assist you today?"},
            {"hello", "Hi! I am here to help you stay safe online!"},
            {"hey", "Hey there! Ready to learn about cybersecurity?"},
            {"greetings", "Greetings! What cybersecurity topic can I help with?"},
            {"how are you", "I'm functioning optimally! Ready to help you stay safe online."},
            {"who are you", "I'm Cyborg, your friendly cybersecurity awareness bot!"},
            {"what can you do", "I can teach you about passwords, phishing, malware, encryption, and more!"},
            
            // === PURPOSE & HELP ===
            {"purpose", "I am here to teach you about Cyber-Security Awareness and best practices."},
            {"help", "Try asking about: passwords, phishing, malware, 2fa, encryption, vpn, ransomware, or data breach!"},
            {"topics", "Available topics: passwords, phishing, malware, firewall, encryption, 2fa, vpn, ransomware, backup, privacy"},
            {"commands", "Type any security term to learn about it. Type 'exit' to quit. Type 'help' for topic list."},
            
            // === PASSWORDS & AUTHENTICATION ===
            {"password", "Use strong passwords: 12+ characters, mix of letters, numbers, symbols. Never reuse!"},
            {"strong password", "Strong passwords: Long (12+ chars), unique, mixed case, numbers, symbols. Use a password manager!"},
            {"password safety", "Password tips: Use unique passwords per site, enable 2FA, change after breaches, use a password manager."},
            {"password manager", "Password managers (Bitwarden, 1Password) generate & store complex passwords securely."},
            {"2fa", "Two-Factor Authentication adds a second verification step (SMS, app, hardware key) beyond your password."},
            {"two factor", "Two-Factor Authentication (2FA) significantly reduces account takeover risk. Enable it everywhere!"},
            {"mfa", "Multi-Factor Authentication (MFA) uses 2+ verification methods. Even stronger than 2FA!"},
            {"biometric", "Biometric auth (fingerprint, face ID) is convenient but should be combined with other factors."},
            {"otp", "One-Time Passwords (OTP) are temporary codes sent via SMS/app for extra login security."},
            
            // === PHISHING & SOCIAL ENGINEERING ===
            {"phishing", "Phishing tricks users into revealing sensitive info via fake emails, texts, or websites. Verify before clicking!"},
            {"phishing tips", "Phishing defense: Check sender addresses, hover over links, don't rush, verify requests via separate channel."},
            {"fake email", "Fake emails often have urgent language, generic greetings, suspicious links, or poor grammar. Verify sender!"},
            {"spear phishing", "Spear phishing targets specific individuals with personalized info. Extra vigilance required!"},
            {"smishing", "Smishing = SMS phishing. Don't click links in unexpected texts. Verify with official sources."},
            {"vishing", "Vishing = voice phishing. Never give sensitive info over unsolicited calls. Hang up & call back officially."},
            {"social engineering", "Social engineering manipulates people into breaking security. Trust but verify!"},
            
            // === MALWARE & THREATS ===
            {"malware", "Malware = malicious software (viruses, ransomware, spyware). Keep systems updated & use antivirus!"},
            {"virus", "A virus attaches to clean files & spreads. Use antivirus & avoid suspicious downloads."},
            {"worm", "Worms self-replicate across networks without user action. Keep firewalls active!"},
            {"trojan", "Trojans disguise as legitimate software. Only download from trusted sources!"},
            {"ransomware", "Ransomware encrypts your files demanding payment. Backup regularly & never pay!"},
            {"spyware", "Spyware secretly monitors your activity. Use reputable security software & avoid pirated content."},
            {"adware", "Adware shows unwanted ads & may track browsing. Install software carefully & decline bundled offers."},
            {"rootkit", "Rootkits hide deep in systems to maintain access. Hard to detect - prevention is key!"},
            {"keylogger", "Keyloggers record keystrokes to steal passwords. Use virtual keyboards for sensitive input."},
            {"botnet", "Botnets are networks of infected devices used for attacks. Keep devices patched!"},
            
            // === NETWORK & WEB SECURITY ===
            {"firewall", "Firewalls monitor & control network traffic. Enable OS firewalls & configure properly!"},
            {"encryption", "Encryption scrambles data so only authorized parties can read it. Look for HTTPS!"},
            {"https", "HTTPS encrypts web traffic. Always check for the padlock icon before entering sensitive info."},
            {"http", "HTTP is unencrypted. Never enter passwords or personal data on HTTP sites."},
            {"vpn", "VPNs encrypt your internet connection & hide your IP. Use reputable providers for privacy."},
            {"public wifi", "Public WiFi is risky. Use a VPN, avoid sensitive transactions, or use mobile hotspot."},
            {"dns", "DNS translates domain names to IPs. Use secure DNS (like Cloudflare 1.1.1.1) to prevent hijacking."},
            {"man in the middle", "MITM attacks intercept communications. Use HTTPS & verify certificates!"},
            
            // === ATTACKS & VULNERABILITIES ===
            {"cyber attack", "Cyber attacks aim to steal, damage, or disrupt. Defense: updates, backups, awareness!"},
            {"ddos", "DDoS floods systems with traffic to crash them. Mitigation requires specialized infrastructure."},
            {"brute force", "Brute force tries many password combos. Defend with strong passwords & account lockouts."},
            {"sql injection", "SQL injection exploits database queries. Developers: use parameterized queries!"},
            {"xss", "XSS injects malicious scripts into web pages. Developers: sanitize user input!"},
            {"zero day", "Zero-day exploits target unknown vulnerabilities. Keep software updated promptly!"},
            {"exploit", "An exploit takes advantage of a vulnerability. Patch management is critical!"},
            {"vulnerability", "A vulnerability is a weakness attackers can exploit. Regular scanning helps find them."},
            
            // === DATA & PRIVACY ===
            {"privacy", "Privacy = controlling your personal data. Review app permissions & privacy settings regularly."},
            {"data breach", "Data breaches expose confidential info. Monitor accounts, use unique passwords, enable alerts."},
            {"backup", "Backup = copy of your data. Follow 3-2-1 rule: 3 copies, 2 media types, 1 offsite!"},
            {"cloud security", "Cloud security = shared responsibility. You secure your data; provider secures infrastructure."},
            {"gdpr", "GDPR protects EU citizens' data privacy. Know your rights: access, deletion, portability."},
            {"data minimization", "Share only necessary personal info. Less data exposed = lower breach impact."},
            
            // === SECURITY ROLES & CONCEPTS ===
            {"cyber security", "Cybersecurity protects systems, networks, & data from digital attacks. Everyone plays a role!"},
            {"white hat", "White hat hackers ethically test security to improve defenses. They have permission!"},
            {"black hat", "Black hat hackers exploit vulnerabilities maliciously. Illegal & harmful."},
            {"gray hat", "Gray hats operate in a moral gray area - may hack without permission but disclose responsibly."},
            {"penetration testing", "Pen testing simulates attacks to find weaknesses. Essential for security validation!"},
            {"security audit", "Security audits assess controls & compliance. Regular audits improve posture."},
            {"incident response", "Incident response = plan for handling breaches. Have a plan BEFORE an attack!"},
            
            // === BEST PRACTICES ===
            {"online safety", "Online safety: Think before you click, verify sources, use strong auth, keep software updated."},
            {"software update", "Updates patch security holes. Enable auto-updates for OS, browsers, apps!"},
            {"antivirus", "Antivirus detects & removes malware. Keep it updated & run regular scans."},
            {"email security", "Email security: Don't open suspicious attachments, verify senders, use spam filters."},
            {"mobile security", "Mobile security: Use screen locks, app permissions carefully, avoid sideloading apps."},
            {"iot security", "IoT devices often have weak security. Change default passwords, segment from main network."},
            {"security awareness", "Security awareness training reduces human error - the #1 attack vector!"},
            
            // === MISC ===
            {"cyber", "'Cyber' relates to computers, networks, and digital systems."},
            {"security", "Security = protection against threats. Digital security requires layers of defense."},
            {"fraud", "Fraud = deception for financial gain. Verify unexpected requests for money or info."},
            {"scam", "Scams trick victims into sending money or data. If it seems too good to be true, it is!"},
            {"spam", "Spam = unwanted bulk messages. Use filters & never reply to suspicious spam."},
            {"spoofing", "Spoofing = impersonating a trusted source. Verify sender addresses & URLs carefully."},
            {"ids", "IDS (Intrusion Detection Systems) monitor networks for suspicious activity."},
            {"ids vs ips", "IDS detects threats; IPS (Intrusion Prevention) actively blocks them."},
            {"endpoint security", "Endpoint security protects devices (laptops, phones) from threats."},
            {"zero trust", "Zero Trust = 'never trust, always verify'. Assume breach & verify every request."},
            
            // === EXIT & FALLBACK ===
            {"exit", "Goodbye! Stay safe online!"},
            {"bye", "Stay vigilant! Come back anytime to learn more."},
            {"thank you", "You're welcome! Keep practicing good security habits."},
            {"thanks", "Anytime! Your security is worth the effort."}
        };
    }

    // ================= KEYWORD MATCHING (No Regex) =================

    static bool ContainsKeyword(string input, string keyword)
    {
        // Split input into words, removing punctuation
        var inputWords = input.ToLower()
            .Split(new char[] { ' ', '.', ',', '!', '?', ';', ':', '"', '\'', '(', ')', '[', ']', '{', '}', '-', '_' },
                   StringSplitOptions.RemoveEmptyEntries);

        // Check if the keyword (which may contain spaces) exists as consecutive words
        var keywordWords = keyword.ToLower().Split(' ');

        if (keywordWords.Length == 1)
        {
            // Single word keyword - simple contains check
            return inputWords.Contains(keywordWords[0]);
        }
        else
        {
            // Multi-word keyword - check for consecutive match
            for (int i = 0; i <= inputWords.Length - keywordWords.Length; i++)
            {
                bool match = true;
                for (int j = 0; j < keywordWords.Length; j++)
                {
                    if (inputWords[i + j] != keywordWords[j])
                    {
                        match = false;
                        break;
                    }
                }
                if (match) return true;
            }
            return false;
        }
    }

    // ================= CHAT ENGINE =================

    static void ChatLoop(string userName, Dictionary<string, string> responses)
    {
        while (true)
        {
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.Write($"\n{userName}: ");
            string? userInput = Console.ReadLine()?.Trim();

            if (string.IsNullOrWhiteSpace(userInput) || userInput.ToLower() == "exit")
            {
                TypeEffect("Cyborg: Goodbye, stay safe online!");
                Speak("Goodbye, stay safe online!");
                break;
            }

            bool found = false;

            // Case-insensitive keyword matching without regex
            foreach (var item in responses)
            {
                if (ContainsKeyword(userInput, item.Key))
                {
                    TypeEffect($"Cyborg: {item.Value}");

                    // Visual feedback for specific topics
                    if (item.Key.Contains("password") || item.Key.Contains("2fa") || item.Key.Contains("mfa"))
                        ShowLock();
                    else if (item.Key.Contains("phishing") || item.Key.Contains("scam"))
                        ShowFish();
                    else if (item.Key.Contains("malware") || item.Key.Contains("virus"))
                        ShowBug();

                    found = true;
                    break;
                }
            }

            if (!found)
            {
                TypeEffect("Cyborg: Hmm, I don't recognize that term. Try: 'help' for topics, or ask about passwords, phishing, malware, 2fa, or encryption!");
            }
        }
    }

    // ================= UI EFFECTS =================

    static void TypeEffect(string message)
    {
        Console.ForegroundColor = ConsoleColor.DarkRed;

        foreach (char c in message)
        {
            Console.Write(c);
            Thread.Sleep(15);
        }
        Console.WriteLine();
        Console.ResetColor();
    }

    static void ShowLock()
    {
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine(@"
      ______
        /      \
       |  SECURE  |
       |  [####]  |
       |  |____|  |
        \________/
        ");
        Console.ResetColor();
    }

    static void ShowFish()
    {
        Console.ForegroundColor = ConsoleColor.DarkBlue;
        Console.WriteLine(@"
       
       <°)))><  Don't take the bait!
        ");
        Console.ResetColor();
    }

    static void ShowBug()
    {
        Console.ForegroundColor = ConsoleColor.DarkGreen;
        Console.WriteLine(@"
        
      /¯\__/¯\  Scan & remove threats!
      \______/ 
        ");
        Console.ResetColor();
    }

    }
    
